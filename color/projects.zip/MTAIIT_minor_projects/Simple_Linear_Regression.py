
from sklearn import datasets
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

#Loading data for regression    
df=pd.read_csv("Salary_Data.csv")

#Splitting data
X,y=df['YearsExperience'].values.reshape(-1,1),df['Salary'].values.reshape(-1,1)

#Calculating slope of Regression Line
X_mean,y_mean=np.mean(X),np.mean(y)
u,d=0.0,0.0
for i in range(len(X)):
    u+=(X[i]-X_mean)*(y[i]-y_mean)
    d+=(X[i]-X_mean)**2
slope=u/d 

#Calculating constant of line
slope=slope[0]
c=y_mean-slope*X_mean
target=slope*X+c

#Plotting Graph
plt.scatter(X,y)
plt.plot(X,target,'r')
plt.xlabel("Age")
plt.ylabel("Salary")
plt.show()