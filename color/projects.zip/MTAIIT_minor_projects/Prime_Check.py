#Function to check the number is prime or not
def isPrime(x):
    prime=True
    for i in range(2,x):
        if x%i==0:
            prime=False
            break
    if(prime):
        print("Prime\n")
    else:
        print('Not Prime\n')

#Loop for I/O
while(True):
	try:
		p=int(input("Enter a number: "))
		if p==1:
			print("Not Prime")
		elif p>0:
			isPrime(p)
		else:
			print("Enter a Positive Integer\n")
	except:
		print("Enter a Positive Integer\n")
	
