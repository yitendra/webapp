import re
import os

#Functions
def add(a,b):
    return a+b
def sub(a,b):
    return a-b
def mult(a,b):
    return a*b
def div(a,b):
    try:
        return a/b
    except ZeroDivisionError:
        print("Cannot divide by Zero.")
        return 'null'

#Infinite Loop
while(True):
    x=input(r"Enter an expression. Example, '2+3':")
    y=re.findall('[\w.]+',x)
    z=re.findall('[^\d.]',x)

    try:
        a=float(y[0])
        b=float(y[1])
    except ValueError:
        print("Numbers should be in Float.")
    except IndexError:
        print("Numbers Not Found!")
    
    try:
        c=z[0]
    except IndexError:
        c=0
    r=0    
    if c=='*':
        r=mult(a,b)
    elif c=='+':
        r=add(a,b)
    elif c=='/':
        r=div(a,b)
    elif c=='-':
        r=sub(a,b)
    else:
        print("Incorrect Expression\nExpression example: '2.2*3.4'")
    print("Result: {}".format(r))


