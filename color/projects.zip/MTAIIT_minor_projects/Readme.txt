MINOR PROJECTS

1.Calculator.exe
step 1: Run calculator.exe to extract files
step 2: Run calculator.exe present in extracted folder

2.Calculator.py
step 1: Run calculator.py directly

3.Prime_Check.py
step 1: Run directly

4.Simple_Linear_Regression.py
step 1: Open CMD in the directory
step 2: in CMD, run command: python simple_linear_regression.py
Note: "Salary_Data.csv" file should be in same directory